/**
 * 
 */
/**
 * 
 */
module AgenciaViagem {
	requires java.sql;
}