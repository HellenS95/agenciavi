package principal;
import java.sql.Connection;
import java.sql.DriverManager;

public class Conexao {

private static final String url = "jdbc:mysql://localhost:3306/agenciauai";

private static final String user = "root";

private static final String password = "root";

private static Connection coon;


public static Connection createConnectionToMySQL() throws Exception{
	//Cria a conexão com o banco de dados
	Connection connection = DriverManager.getConnection(url,
	user, password);
	return connection;
	}




}