package principal;

public class CompanhiaAerea {

	private int id;
	private String nome;
	private String numeroContato;
	
	public CompanhiaAerea(int id, String nome, String numeroContato) {
	    this.setId(id);
	    this.setNome(nome);
	    this.setNumeroContato(numeroContato);

	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getNumeroContato() {
		return numeroContato;
	}

	public void setNumeroContato(String numeroContato) {
		this.numeroContato = numeroContato;
	}

	
}
