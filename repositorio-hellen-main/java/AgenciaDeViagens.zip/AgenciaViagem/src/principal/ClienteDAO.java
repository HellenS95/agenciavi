package principal;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class ClienteDAO {
	Connection conn = null;
	PreparedStatement pstm = null;
	
		
	public void cadastrarCliente(Cliente cliente) {
		
		String sql = "INSERT INTO clientes (nome,email,senha) VALUES (?,?,?)";
	
		try {
			// cria conexão com banco de  dados
			conn = Conexao.createConnectionToMySQL();
			// cria um prepared stament, classe  para executar  a query
			
			pstm = conn.prepareStatement(sql);
			
			// adiciona o valor do primeiro parametro da sql
			
			pstm.setString(1, cliente.getNome());
			
			// adicionao o valor do  2 parametro da sql
			
			pstm.setString(2, cliente.getEmail());
			
			// adicionao o valor do  3 parametro da sql
			
			pstm.setString(3, cliente.getSenha());
			
			// Executa a sql para inserção dos dados
			pstm.execute();
			
		}catch(Exception e) {
			e.printStackTrace();
		} finally {
			// fecha as conexões
			
			try {
				if(pstm != null) {
					pstm.close();
				}
			} catch(Exception e) {
				e.printStackTrace();

			}
		}
		
		
	}
	
	public void excluirCliente(Cliente cliente, int id) {

		String sql = "DELETE FROM clientes WHERE id = ?";
	
		try {
			conn = Conexao.createConnectionToMySQL();			
			pstm = conn.prepareStatement(sql);		
			
			// Define o valor do parâmetro
	        pstm.setInt(1, id);

	        // Executa a query
	        pstm.execute();
		} catch(Exception e) {
			e.printStackTrace();
		} finally {
			 try {
		            if (pstm != null) {
		                pstm.close();
		            }
		        } catch (Exception e) {
		            e.printStackTrace();
		        }
		}
	
	}
	
	public List<Cliente> listarClientes() {
	    String sql = "SELECT id, nome, email FROM clientes;";
	    List<Cliente> clientes = new ArrayList<>();

	    try {
	        conn = Conexao.createConnectionToMySQL();
	        pstm = conn.prepareStatement(sql);
	        ResultSet rs = pstm.executeQuery();

	        while (rs.next()) {
	            int id = rs.getInt("id"); 
	            String nome = rs.getString("nome"); 
	            String email = rs.getString("email"); 

	          
	            Cliente cliente = new Cliente(id,nome,email, "");
	            clientes.add(cliente);
	        }
	    } catch (Exception e) {
	        e.printStackTrace();
	    } finally {
	        try {
	            if (pstm != null) {
	                pstm.close();
	            }
	        } catch (Exception e) {
	            e.printStackTrace();
	        }
	    }

	    return clientes;
	}

}
