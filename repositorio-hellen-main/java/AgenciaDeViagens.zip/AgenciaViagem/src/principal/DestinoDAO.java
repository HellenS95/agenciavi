package principal;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class DestinoDAO {
	Connection conn = null;
	PreparedStatement pstm = null;
	
	public void cadastrarDestino(Destino destino) {
		String sql = "INSERT INTO destinos (pais,descricao) VALUES (?,?)";
		try {
			conn = Conexao.createConnectionToMySQL();
			
			pstm = conn.prepareStatement(sql);
			
			
			pstm.setString(1, destino.getPais());
			pstm.setString(2, destino.getDescricao());

			pstm.execute();
			
		}catch(Exception e) {
			e.printStackTrace();
		} finally {
			
			try {
				if(pstm != null) {
					pstm.close();
				}
			} catch(Exception e) {
				e.printStackTrace();

			}
		}
		

	}
	
	public void excluirDestino(Destino destino,int id) {
		String sql = "DELETE FROM destinos WHERE id = ?";
		
		try {
			conn = Conexao.createConnectionToMySQL();			
			pstm = conn.prepareStatement(sql);		
			
			// Define o valor do parâmetro
	        pstm.setInt(1, id);

	        // Executa a query
	        pstm.execute();
		} catch(Exception e) {
			e.printStackTrace();
		} finally {
			 try {
		            if (pstm != null) {
		                pstm.close();
		            }
		        } catch (Exception e) {
		            e.printStackTrace();
		        }
		}
	}
	
	public List<Destino> listarDestinos() {
		String sql = "SELECT id, pais, descricao FROM destinos;";
	    List<Destino> destinos = new ArrayList<>();

	    try {
	        conn = Conexao.createConnectionToMySQL();
	        pstm = conn.prepareStatement(sql);
	        ResultSet rs = pstm.executeQuery();

	        while (rs.next()) {
	            int id = rs.getInt("id"); 
	            String pais = rs.getString("pais"); 
	            String descricao = rs.getString("descricao"); 

	          
	            Destino destino = new Destino(id,pais,descricao);
	            destinos.add(destino);
	        }
	    } catch (Exception e) {
	        e.printStackTrace();
	    } finally {
	        try {
	            if (pstm != null) {
	                pstm.close();
	            }
	        } catch (Exception e) {
	            e.printStackTrace();
	        }
	    }

	    return destinos;
	}
}
