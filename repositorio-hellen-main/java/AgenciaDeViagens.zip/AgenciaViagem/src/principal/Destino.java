package principal;

public class Destino {
	
	private int id;
	private  String pais;
	private String descricao;
	
public Destino(int id, String pais, String descricao) {
	this.id = id;
	this.pais = pais;
	this.descricao = descricao;
}

	public String getPais() {
		return pais;
	}
	public void setPais(String pais) {
		this.pais = pais;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getDescricao() {
		return descricao;
	}
	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}

}
