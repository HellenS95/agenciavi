package principal;

import java.util.List;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        ClienteDAO clienteDAO = new ClienteDAO();
        Cliente cliente = new Cliente(0, null, null, null);
        CompanhiaAereaDAO companhiaDAO = new CompanhiaAereaDAO();
        CompanhiaAerea companhia = new CompanhiaAerea(0, null, null);
        DestinoDAO destinoDAO = new DestinoDAO();
        Destino destino = new Destino(0, null, null);

        Scanner entrada = new Scanner(System.in);

        int escolha;
        do {
            System.out.println("Selecione uma opção:");
            System.out.println("1. Cadastrar Cliente");
            System.out.println("2. Remover Cliente");
            System.out.println("3. Listar Clientes");
            System.out.println("4. Cadastrar Companhia");
            System.out.println("5. Excluir Companhia");
            System.out.println("6. Listar Companhias");
            System.out.println("7. Cadastrar Destino");
            System.out.println("8. Excluir Destino");
            System.out.println("9. Listar Destinos");
            System.out.println("0. Sair");
            escolha = entrada.nextInt();
            
            switch (escolha) {
                case 1:
                    System.out.println("Informe o nome do cliente:");
                    entrada.nextLine();
                    cliente.setNome(entrada.nextLine());
                    System.out.println("Informe o email do cliente:");
                    cliente.setEmail(entrada.nextLine());
                    System.out.println("Informe a senha do cliente:");
                    cliente.setSenha(entrada.nextLine());
                    clienteDAO.cadastrarCliente(cliente);
                    System.out.println("Cliente cadastrado com sucesso!");
                    break;
                case 2:
                    System.out.println("Informe o ID que deseja remover:");
                    int clienteId = entrada.nextInt();
                    clienteDAO.excluirCliente(cliente, clienteId);
                    System.out.println("Cliente removido com sucesso!");
                    break;
                case 3:
                    System.out.println("Lista de Clientes:");
                    List<Cliente> clientes = clienteDAO.listarClientes();

                    if (clientes.isEmpty()) {
                        System.out.println("Nenhum cliente cadastrado.");
                    } else {
                        for (Cliente c : clientes) {
                            System.out.println("ID: " + c.getId());
                            System.out.println("Nome: " + c.getNome());
                            System.out.println("Email: " + c.getEmail());
                            System.out.println("----------");
                        }
                    }
                    break;
                case 4:
                    System.out.println("Informe o nome da Companhia:");
                    entrada.nextLine();
                    companhia.setNome(entrada.nextLine());
                    System.out.println("Informe o numero de contato da Companhia:");
                    companhia.setNumeroContato(entrada.nextLine());
                    companhiaDAO.cadastrarCompanhia(companhia);
                    System.out.println("Companhia cadastrada com sucesso!");
                    break;
                case 5:
                    System.out.println("Informe o ID que deseja remover:");
                    int companhiaId = entrada.nextInt();
                    companhiaDAO.excluirCompanhia(companhia, companhiaId);
                    System.out.println("Companhia removida com sucesso!");
                    break;
                case 6:
                    System.out.println("Lista de Companhias:");
                    List<CompanhiaAerea> companhias = companhiaDAO.listarCompanhias();

                    if (companhias.isEmpty()) {
                        System.out.println("Nenhuma companhia cadastrada.");
                    } else {
                        for (CompanhiaAerea c : companhias) {
                            System.out.println("ID: " + c.getId());
                            System.out.println("Nome: " + c.getNome());
                            System.out.println("Número de Contato: " + c.getNumeroContato());
                            System.out.println("----------");
                        }
                    }
                    break;
                case 7: 
                    System.out.println("Cadastrar Destino");
                    entrada.nextLine();                    
                    System.out.println("Informe o pais:");
                    destino.setPais(entrada.nextLine());
                   System.out.println("Informe a descricao do destino:");              
                    destino.setDescricao(entrada.nextLine());

                    destinoDAO.cadastrarDestino(destino);
                    System.out.println("Destino cadastrado com sucesso!");
                	break;
                	
                case 8:
                    System.out.println("Informe o ID que deseja remover:");
                    int destinoId = entrada.nextInt();
                    destinoDAO.excluirDestino(destino, destinoId);;
                    System.out.println("Destino removido com sucesso!");
                	break;
                	
                case 9: 
                    System.out.println("Lista de Destinos");
                    List<Destino> destinos = destinoDAO.listarDestinos();

                    if (destinos.isEmpty()) {
                        System.out.println("Nenhum destino cadastrado.");
                    } else {
                        for (Destino d : destinos) {
                            System.out.println("ID: " + d.getId());
                            System.out.println("Pais: " + d.getPais());
                            System.out.println("Descricao: " + d.getDescricao());
                            System.out.println("----------");
                        }
                    }
                	break;
                case 0:
                    System.out.println("Saindo do programa.");
                    break;
                default:
                    System.out.println("Opção inválida. Tente novamente.");
            }
        } while (escolha != 0);

        entrada.close();
    }
}

